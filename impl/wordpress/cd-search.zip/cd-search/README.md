# Compdeep Search Plugin

A plugin that implements search and suggest api

# Install
Copy files into plugin directory and enable plugin.

You then need to add the searchbox[form] into the theme at the required position.

<div class="cd-search-container">
  <form method="post" class="cd-search">
    <input id="cd-search" type="text" name="doing_form" value="" class="cd-search" target="_blank" action="cd-search.php"/>
  </form>
  <div id="cd-results" ></div>
</div>

## WordPress Plugin For compdeep's lightweight search engine:

- [Compdeep Search](https://compdeep.com/search)
- [Giga Store](https://giga.store)

